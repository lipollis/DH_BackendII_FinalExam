package com.lipollis.seriesservice.api.service;


import com.lipollis.seriesservice.domain.model.Serie;

import java.util.List;

public interface SerieService {

    Serie create(Serie serie);
    List<Serie> getAll();
    Serie getById(String id);
    void delete(String id);
}
