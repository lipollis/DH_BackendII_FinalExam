package com.lipollis.seriesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeriesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
